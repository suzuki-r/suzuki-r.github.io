(* ::Package:: *)

(* ::Section:: *)
(*Preliminary definitions*)


(* ::Text:: *)
(*((Notation))*)


(* ::Input::Initialization:: *)
FS=FullSimplify;
MF=MatrixForm;
GRow=GraphicsRow;
ISize=ImageSize;

<<Notation`
(* LHS is Subsuperscript *)
{Notation[ParsedBoxWrapper[TemplateBox[{TemplateBox[{"\[CapitalPhi]", "a_"}, "Superscript"], "i_", "j_"}, "Subsuperscript"]] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[RowBox[{"\[Phi]", "[", RowBox[{"a_", ",", "i_", ",", "j_"}], "]"}]]],Notation[ParsedBoxWrapper[SubscriptBox["x", RowBox[{"k_", ",", "l_"}]]] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[RowBox[{"x", "[", RowBox[{"{", RowBox[{"k_", ",", "l_"}], "}"}], "]"}]]],Notation[ParsedBoxWrapper[TemplateBox[{"\[CapitalDelta]", RowBox[{"{", RowBox[{"b_", ",", "l_"}], "}"}], RowBox[{"{", RowBox[{"a_", ",", "k_"}], "}"}]}, "Subsuperscript"]] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[RowBox[{"\[CapitalDelta]", "[", RowBox[{RowBox[{"{", RowBox[{"a_", ",", "k_"}], "}"}], ",", RowBox[{"{", RowBox[{"b_", ",", "l_"}], "}"}]}], "]"}]]]};
{Notation[ParsedBoxWrapper[SubscriptBox["h", RowBox[{"k_", ",", "l_"}]]] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[RowBox[{"h", "[", RowBox[{"k_", ",", "l_"}], "]"}]]]};
{Notation[ParsedBoxWrapper[SubscriptBox["jm", RowBox[{"k_", ",", "l_"}]]] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[RowBox[{"jm", "[", RowBox[{"k_", ",", "l_"}], "]"}]]]};


(* ::Text:: *)
(*((Wick))*)
(*From Pedro's Lecture_2.nb in Mathematica School 2013, http://msstp.org/?q=node/286*)


(* ::Input::Initialization:: *)
wick[X_Times]:=Block[{list=List@@X},\!\(
\*UnderoverscriptBox[\(\[Sum]\), \(n = 2\), \(Length[list]\)]\(\[LeftAngleBracket]list[\([1]\)], list[\([n]\)]\[RightAngleBracket]\ wick[Times @@ Drop[Drop[list, {n}], 1]]\)\)];
wick[1]=1;

Attributes[\[Delta]]={Orderless};
Attributes[\[CapitalDelta]]={Orderless};

(* AngleBracket represents the propagator *)
\[LeftAngleBracket]\[Phi][I_,i_,j_][x[a_]],\[Phi][J_,k_,l_][x[a_]]\[RightAngleBracket]=0;
\[LeftAngleBracket]\[Phi][A[a_,I_],i_,j_][x[a_]],\[Phi][A[b_,J_],k_,l_][x[b_]]\[RightAngleBracket]:=\[CapitalDelta][{a,I},{b,J}]\[Delta][i,l]\[Delta][k,j] 1/x[Sort@{a,b}]^2;
(* SO(\[GothicN]), U(\[DoubleStruckCapitalN]) Wick rules *)
indices={\[CapitalDelta][{a_,k_},{b_,l_}]^2:>\[GothicN],\[CapitalDelta][{a_,k_},{a_,k_}]:>\[GothicN],\[CapitalDelta][{a_,k_},{b_,l_}]\[CapitalDelta][{b_,l_},{c_,m_}]:>\[CapitalDelta][{a,k},{c,m}],\[Delta][a_,b_]^2:>\[DoubleStruckCapitalN],\[Delta][a_,a_]:>\[DoubleStruckCapitalN],\[Delta][a_,b_]\[Delta][b_,c_]:>\[Delta][a,c]};


(* ::Text:: *)
(*((Operators))*)


(* ::Input::Initialization:: *)
(* single traces *)
Do[o[k,1]=\[Phi][A[k,1],i,i][x[k]]/.{i->Unique[i]},{k,6}];
Do[o[k,2]=\[Phi][A[k,1],i,j][x[k]]\[Phi][A[k,2],j,i][x[k]]/.{i->Unique[i],j->Unique[j]},{k,6}];
Do[o[k,3]=\[Phi][A[k,1],i1,i2][x[k]]\[Phi][A[k,2],i2,i3][x[k]]\[Phi][A[k,3],i3,i1][x[k]]/.{i1->Unique[i1],i2->Unique[i2],i3->Unique[i3]},{k,5}];
Do[o[k,4]=\[Phi][A[k,1],i1,i2][x[k]]\[Phi][A[k,2],i2,i3][x[k]]\[Phi][A[k,3],i3,i4][x[k]]\[Phi][A[k,4],i4,i1][x[k]]/.{i1->Unique[i1],i2->Unique[i2],i3->Unique[i3],i4->Unique[i4]},{k,4}];
Do[o[k,5]=\[Phi][A[k,1],i1,i2][x[k]]\[Phi][A[k,2],i2,i3][x[k]]\[Phi][A[k,3],i3,i4][x[k]]\[Phi][A[k,4],i4,i5][x[k]]\[Phi][A[k,5],i5,i1][x[k]]/.{i1->Unique[i1],i2->Unique[i2],i3->Unique[i3],i4->Unique[i4],i5->Unique[i5]},{k,4}];
Do[o[k,6]=\[Phi][A[k,1],i1,i2][x[k]]\[Phi][A[k,2],i2,i3][x[k]]\[Phi][A[k,3],i3,i4][x[k]]\[Phi][A[k,4],i4,i5][x[k]]\[Phi][A[k,5],i5,i6][x[k]]\[Phi][A[k,6],i6,i1][x[k]]/.{i1->Unique[i1],i2->Unique[i2],i3->Unique[i3],i4->Unique[i4],i5->Unique[i5],i6->Unique[i6]},{k,4}];

(* list of operator lengths without 1 *)
MaxLength=14;
opLis3=Select[Select[Select[
(Flatten@Table[Table[Table[c[Sort[{i,j,k},Greater]],{k,2,j}],{j,2,i}],{i,2,6}]/.c->Plus),EvenQ[Total[#]]&],Total[#]<=MaxLength&],#[[1]]<=Total[#[[2;;]]]&];

opLis4=Select[Select[Select[
(Flatten@Table[Table[Table[Table[c[Sort[{i,j,k,l},Greater]],{l,2,k}],{k,2,j}],{j,2,i}],{i,2,6}]/.c->Plus),EvenQ[Total[#]]&],Total[#]<=MaxLength&],#[[1]]<=Total[#[[2;;]]]&];
opLis5=Select[Select[Select[
(Flatten@Table[Table[Table[Table[Table[c[Sort[{i,j,k,l,m},Greater]],{m,2,l}],{l,2,k}],{k,2,j}],{j,2,i}],{i,2,6}]/.c->Plus),EvenQ[Total[#]]&],Total[#]<=MaxLength&],#[[1]]<=Total[#[[2;;]]]&];


(* ::Text:: *)
(*((Permutations))*)


(* ::Input::Initialization:: *)
PGr=PermutationGroup;
PPr=PermutationProduct;
PRe=PermutationReplace;
InvP=InversePermutation;

numberOfCycles[cycle_,LL_]:=Module[{lis=cycle/.Cycles->Plus,num1},
num1=Complement[Range[LL],Flatten@lis];
Length@lis+Length@num1
];

(* For Wick *)
Attributes[h]={Orderless};

H[lis_List]:=h[lis[[1]],lis[[2]]]/;Length@lis==2;
H[lis_List]:=Expand[1/(2(Length@lis-2)!) Total@Table[h[lis[[PRe[1,\[Pi]]]],lis[[PRe[2,\[Pi]]]]]Product[KroneckerDelta[lis[[PRe[jj,\[Pi]]]],1],{jj,3,Length@lis}],{\[Pi],GroupElements@SymmetricGroup[Length@lis]}]]/;Length@lis>2;

(* For graphs *)
lengthSum[Ltt_List]:=Table[Sum[Ltt[[i1]],{i1,j1}],{j1,Length@Ltt}];
singleTraceGen[Ltt_List]:=Module[{lsum=Join[{0},lengthSum[Ltt]]},
Flatten@Table[Table[lsum[[ii]]+jj->lsum[[ii]]+Mod[jj+1,Ltt[[ii]],1],{jj,Ltt[[ii]]}],{ii,Length@Ltt}]
];
singleTraceCyc[Ltt_List]:=Module[{lsum=Join[{0},lengthSum[Ltt]]},
PermutationCycles@Flatten@Table[Table[lsum[[ii]]+Mod[jj+1,Ltt[[ii]],1],{jj,Ltt[[ii]]}],{ii,Length@Ltt}]
];
DeltaToEdge[deltas_,Ltt_List]:=Module[{lsum=Join[{0},lengthSum[Ltt]],dlist=Select[(deltas/.Times->List),!NumericQ[#]&]},
dlist/.\[CapitalDelta][{a_,j_},{b_,k_}]:>{lsum[[a]]+j,lsum[[b]]+k}
];

polyToList[poly_]:=DeleteCases[Apply[List,Expand[poly+\[Omega]\[Omega]]]/.\[Omega]\[Omega]->0,0];
polyToCoeffList[poly_,var_]:=Module[{list=DeleteCases[Apply[List,Expand[poly+\[Omega]\[Omega]]]/.\[Omega]\[Omega]->0,0],coeffs},
coeffs=list/.var[any___]->1;
{coeffs,list/coeffs}//Expand
];
(* multi-variables *)
polyToCoeffList[poly_,vars_List]:=Module[{list=DeleteCases[List@@Expand[poly+\[Omega]\[Omega]]/. \[Omega]\[Omega]->0,0],coeffs},coeffs=list/.Table[ vars[[ii]][any___]->1,{ii,Length@vars}];Expand[{coeffs,list/coeffs}]];

(* Wreath product Sm[Zn] *)
WreathSZ[m_,n_]:=Module[{genZn=(Cs/@Partition[Table[i,{i,m*n}],n])/.Cs[lis_]->Cycles[{lis}],
genSm=Flatten@Map[Cs,Table[Table[Flatten@Table[{a*n+ii,b*n+ii},{ii,n}],{b,a+1,m-1}],{a,0,m-2}],{2}]/.Cs[lis_]->Cycles[{lis}]},
PermutationGroup[Join[genZn,genSm]]
]

wreathLength[llis_]:=Times@@(#[[1]]^#[[2]] (#[[2]]!)&/@Tally[llis]);
wreathOrbitsFromCycles[lis_]:=Module[{cycGroup,permGroup},
cycGroup=Map[Cycles[List[#]]&,lis,{1}];
permGroup=Cycles/@Table[If[Length[lis[[ii]]]==Length[lis[[ii+1]]],Transpose[{lis[[ii]],lis[[ii+1]]}],{{}}],{ii,Length@lis-1}];
Table[PermutationReplace[lis,pm],{pm,GroupElements@PermutationGroup[Join[cycGroup,permGroup]]}]
];

(* canonical label for bridges *)
subCedge[cyc_]:=Module[{lis=Plus@@cyc},
Join@@Table[{lis[[i,1]]->Subscript[e, i],lis[[i,2]]->Subscript[eb, i]},{i,Length@lis}]
]

(* vertex coordinates for plot *)
singletrVC[Ltt_List,offset_List,Rsmall_]:=Module[{Lmax=Max[Ltt],nn=Length@Ltt,Rbig},
Rbig=nn/\[Pi]^2 Lmax;
Flatten@Table[Table[cc[Rbig{Cos[\[Pi]/2+(2\[Pi] (ii-1))/nn],Sin[\[Pi]/2+(2\[Pi] (ii-1))/nn]}+Rsmall{Cos[\[Pi]/2+(2\[Pi] (jj-1+offset[[ii]]))/Ltt[[ii]]],Sin[\[Pi]/2+(2\[Pi] (jj-1+offset[[ii]]))/Ltt[[ii]]]}],{jj,Ltt[[ii]]}],{ii,Length@Ltt}]/.cc->Plus//N//Chop
];
singletrVC[Ltt_List,offset_List]:=singletrVC[Ltt,offset,Max[Ltt]/(2\[Pi])];
(* for graph drawing *)
externalOpGen[alpha_List]:=Module[{\[Alpha]len=Length/@alpha},
Flatten@Table[Join[Table[alpha[[ii,jj]]->alpha[[ii,jj+1]],{jj,\[Alpha]len[[ii]]-1}],{alpha[[ii,-1]]->alpha[[ii,1]]}],{ii,Length@\[Alpha]len}]
];

(* permute \[LeftAngleBracket]O1, O2, ..., On\[RightAngleBracket] *)
permuteOpLabel[opOrder_,blList_]:=Module[{inds,bLind=Most@Join[{0},lengthSum[blList]]+Range/@blList},
inds=bLind[[First@opOrder]];
Fold[Join[#1,Part[bLind,#2]]&,inds,Rest@opOrder]
];


(* ::Text:: *)
(*((Extra))*)


(* ::Input::Initialization:: *)
listToSingleTrace[lis_]:=Join[
Table[lis[[ii]]->lis[[ii+1]],{ii,Length@lis-1}],{lis[[-1]]->lis[[1]]}];
subsListToPositions[alis_]:=
Flatten@Table[Table[c[ii,jj],{jj,Length[alis[[ii]]]}],{ii,Length[alis]}]/.c->List;

flavorFromCycles[alis_,Ll_]:=Module[{wind=Partition[Table[First@Position[alis,ii],{ii,2Ll}],2]},
Product[h@@(A@@@wind[[ii]]),{ii,Ll}]
];


(* ::Section::Closed:: *)
(*Generating connected n-pt*)


(* ::Text:: *)
(*((Indices))*)


(* ::Input::Initialization:: *)
(* Functions which generate disconnected terms *)
Choices[5]=Sort/@Permutations[{a,b,c,d,e}][[All, ;;2]]//DeleteDuplicates;
DCI[5]=MapThread[List,{Choices[5],(Complement[{a,b,c,d,e},#]&/@Choices[5])}];
ChoiceNum[5]=Sort/@Permutations[Range[5]][[All, ;;2]]//DeleteDuplicates;
ChoiceNum[2,3]=MapThread[List,{ChoiceNum[5],(Complement[Range[5],#]&/@ChoiceNum[5])}];
DCNsub[5]=Table[{DCI[5][[i,1]]->ChoiceNum[2,3][[i,1]],DCI[5][[i,2]]->ChoiceNum[2,3][[i,2]]},{i,Length@DCI[5]}];
tabDCG[5]=Total@Table[If[DCI[5][[ii,1,1]]==DCI[5][[ii,1,2]],Evaluate[Gc[DCI[5][[ii,1,1]],DCI[5][[ii,1,2]],DCI[5][[ii,1]]]Gc[DCI[5][[ii,2,1]],DCI[5][[ii,2,2]],DCI[5][[ii,2,3]],DCI[5][[ii,2]]]/.DCNsub[5][[ii]]],0],{ii,Length@DCI[5]}];


(* ::Text:: *)
(*((Generate the orbits of trace cyclicity))*)


(* ::Input::Initialization:: *)
(* genCyclic generates all elements of trace cyclicity *)
genCyclic[seeds_,lenlis_]:=Module[{summand,ss},
summand=seeds/.\[CapitalDelta][{a_,k_},{b_,l_}]:>\[CapitalDelta][{a,Mod[k+ss[a],lenlis[[a]],1]},{b,Mod[l+ss[b],lenlis[[b]],1]}];
(Sum[summand,##]&)@@Table[{ss[ii],lenlis[[ii]]},{ii,Length@lenlis}]
];

(* normalized as the maximal coefficient = (original coeff), the coefficient should be chosen differently for each seed term *)
genCyclicCoeff[seed_,lenlis_]:=Module[{summand,ss,sum,coeff,ORcoeff},
ORcoeff=seed/.{\[DoubleStruckCapitalN]->1,\[CapitalDelta][any___]->1};
summand=seed/.\[CapitalDelta][{a_,k_},{b_,l_}]:>\[CapitalDelta][{a,Mod[k+ss[a],lenlis[[a]],1]},{b,Mod[l+ss[b],lenlis[[b]],1]}];
sum=(Sum[summand,##]&)@@Table[{ss[ii],lenlis[[ii]]},{ii,Length@lenlis}];
coeff=Max[List@@sum/.{\[DoubleStruckCapitalN]->1,\[CapitalDelta][any___]->1}];
{ORcoeff/coeff sum,coeff/ORcoeff}//Expand
]

numND=Flatten@{\[DoubleStruckCapitalN]->10,Table[Table[\[CapitalDelta][{a,k},{b,l}]->RandomComplex[],{a,b-1},{k,6}],{b,5},{l,6}]};

(* If we want to revoer the spacetime dependence *)
subSPT={\[CapitalDelta][{a_,k_},{b_,l_}]->\[CapitalDelta][{a,k},{b,l}]/x[{a,b}]^2};


(* ::Text:: *)
(*((two-point functions collectively))*)


(* ::Input::Initialization:: *)
G[2,2]=Expand[wick[o[1,2]o[2,2]]]//.indices//Collect[#,\[DoubleStruckCapitalN]]&;
G[3,3]=Expand[wick[o[1,3]o[2,3]]]//.indices//Collect[#,\[DoubleStruckCapitalN]]&;
G[4,4]=Expand[wick[o[1,4]o[2,4]]]//.indices//Collect[#,\[DoubleStruckCapitalN]]&;
G[5,5]=Expand[wick[o[1,5]o[2,5]]]//.indices//Collect[#,\[DoubleStruckCapitalN]]&;
G[6,6]=Expand[wick[o[1,6]o[2,6]]]//.indices//Collect[#,\[DoubleStruckCapitalN]]&;


(* ::Text:: *)
(*((subtracting the disconnected parts))*)


(* ::Input::Initialization:: *)
(* neglect spacetime dependence for simplicity *)
Gc[mm_,mm_,{a_,b_}]:=G[mm,mm]/.\[CapitalDelta][{1,k_},{2,l_}]->\[CapitalDelta][{a,k},{b,l}]/.x[{any_,any2_}]->1;
Gc[m1_,m2_,m3_,{a_,b_,c_}]:=G[m1,m2,m3]/.{\[CapitalDelta][{1,k_},{2,l_}]->\[CapitalDelta][{a,k},{b,l}],\[CapitalDelta][{1,k_},{3,l_}]->\[CapitalDelta][{a,k},{c,l}],\[CapitalDelta][{2,k_},{3,l_}]->\[CapitalDelta][{b,k},{c,l}]}/.x[{any_,any2_}]->1;
GC[{a_,b_,c_}]:=GC[{a,b,c}]=G[a,b,c]/.x[{any_,any2_}]->1;
GC[{a_,b_,c_,d_}]:=GC[{a,b,c,d}]=G[a,b,c,d]-If[a==b&&c==d,Gc[a,b,{1,2}]Gc[c,d,{3,4}],0]-If[a==c&&b==d,Gc[a,c,{1,3}]Gc[b,d,{2,4}],0]-If[a==d&&b==c,Gc[a,d,{1,4}]Gc[b,c,{2,3}],0]/.x[{any_,any2_}]->1;
GC[{a_,b_,c_,d_,e_}]:=GC[{a,b,c,d,e}]=G[a,b,c,d,e]-(If[a==b,Gc[a,b,{1,2}]Gc[c,d,e,{3,4,5}],0]+If[a==c,Gc[a,c,{1,3}]Gc[b,d,e,{2,4,5}],0]+If[a==d,Gc[a,d,{1,4}]Gc[b,c,e,{2,3,5}],0]+If[a==e,Gc[a,e,{1,5}]Gc[b,c,d,{2,3,4}],0]+If[b==c,Gc[b,c,{2,3}]Gc[a,d,e,{1,4,5}],0]+If[b==d,Gc[b,d,{2,4}]Gc[a,c,e,{1,3,5}],0]+If[b==e,Gc[b,e,{2,5}]Gc[a,c,d,{1,3,4}],0]+If[c==d,Gc[c,d,{3,4}]Gc[a,b,e,{1,2,5}],0]+If[c==e,Gc[c,e,{3,5}]Gc[a,b,d,{1,2,4}],0]+If[d==e,Gc[d,e,{4,5}]Gc[a,b,c,{1,2,3}],0])/.x[{any_,any2_}]->1;

(* same function for GV,GE,GF *)
GVC[{a_,b_,c_}]:=GVC[{a,b,c}]=GV[{a,b,c}];
GEC[{a_,b_,c_}]:=GEC[{a,b,c}]=GE[{a,b,c}];
GFC[{a_,b_,c_}]:=GFC[{a,b,c}]=GF[{a,b,c}];

GVC[{a_,b_,c_,d_}]:=GVC[{a,b,c,d}]=GV[{a,b,c,d}]-If[a==b&&c==d,Gc[a,b,{1,2}]Gc[c,d,{3,4}],0]-If[a==c&&b==d,Gc[a,c,{1,3}]Gc[b,d,{2,4}],0]-If[a==d&&b==c,Gc[a,d,{1,4}]Gc[b,c,{2,3}],0]/.x[{any_,any2_}]->1;
GEC[{a_,b_,c_,d_}]:=GEC[{a,b,c,d}]=GE[{a,b,c,d}]-If[a==b&&c==d,Gc[a,b,{1,2}]Gc[c,d,{3,4}],0]-If[a==c&&b==d,Gc[a,c,{1,3}]Gc[b,d,{2,4}],0]-If[a==d&&b==c,Gc[a,d,{1,4}]Gc[b,c,{2,3}],0]/.x[{any_,any2_}]->1;
GFC[{a_,b_,c_,d_}]:=GFC[{a,b,c,d}]=GF[{a,b,c,d}]-If[a==b&&c==d,Gc[a,b,{1,2}]Gc[c,d,{3,4}],0]-If[a==c&&b==d,Gc[a,c,{1,3}]Gc[b,d,{2,4}],0]-If[a==d&&b==c,Gc[a,d,{1,4}]Gc[b,c,{2,3}],0]/.x[{any_,any2_}]->1;


(* ::Section::Closed:: *)
(*Skeleton reduction*)


(* ::Input::Initialization:: *)
edgeClassify[\[Alpha]c_,hL_]:=Table[First@First@Position[#,ii],{ii,hL}]&@(Plus@@\[Alpha]c);
edgeCsubs[\[Alpha]c_,hL_]:=Table[ii->First@First@Position[#,ii],{ii,hL}]&@(Plus@@\[Alpha]c);

(* returns the number of extremal ops {0,1,2} given an (i,j) sector *)
findExtremalSectors[pairSector_]:=Module[{sectorLength=Length/@pairSector,bridgeDist,opExtremal},
bridgeDist=Part[sectorLength,#]&/@opsBridgeInd;
opExtremal=(nn-2-Count[#,0])&/@bridgeDist;
Count[Part[opExtremal,#],0]&/@opsPairSet
];
(* generate Wick-edge groups from the edge labels and edge-adjacency matrix J.
first count the number of external adjacent edges *)
genEdgeGroup[edges_,Jm_,extremality_]:=If[Jm=={},Nothing,
Which[extremality==0,genEdgeGroupNonExtremal[edges,Jm],
extremality==1,genEdgeGroupExtremal[edges,Jm],
extremality<0||extremality>1,Print["Extreme Error ",extremality]]
];

(* replace edge indices only once, First or Last *)
replaceOnceEa[sth_,x_]:=Module[{pos=Position[sth,x]},
If[pos!={},ReplacePart[sth,First@pos->Subscript[\[DoubleStruckE]a, x]],sth]
];
replaceOnceEb[sth_,x_]:=Module[{pos=Position[sth,x]},
If[pos!={},ReplacePart[sth,Last@pos->Subscript[\[DoubleStruckE]b, x]],sth]
];
genEdgeGroupNonExtremal[edges_,Jm_]:=If[(4Length[#]-4-Nest[Total,#,2])&@Jm<=0,{eg[edges]},
Switch[Jm,
{{0}},eg[List[#]]&/@edges,
{{0,0},{0,0}},eg[List[#]]&/@edges,
{{0,1},{1,0}},eg[List[#]]&/@edges,
{{0,1,1},{1,0,1},{1,1,0}},eg[List[#]]&/@edges,
{{0,1,0},{1,0,1},{0,1,0}},eg[List[#]]&/@edges,
{{0,1,1},{1,0,0},{1,0,0}},eg[List[#]]&/@edges,
{{0,1,0},{1,0,1},{0,1,0}},eg[List[#]]&/@edges,
{{0,0,1},{0,0,1},{1,1,0}},eg[List[#]]&/@edges,
{{0,1,1,0},{1,0,1,1},{1,1,0,1},{0,1,1,0}},eg[List[#]]&/@edges,
{{0,0,1,1},{0,0,1,1},{1,1,0,1},{1,1,1,0}},eg[List[#]]&/@edges,
{{0,1,1,1},{1,0,1,0},{1,1,0,1},{1,0,1,0}},eg[List[#]]&/@edges,
{{0,1,1,1},{1,0,0,1},{1,0,0,1},{1,1,1,0}},eg[List[#]]&/@edges,
{{0,1,1,1},{1,0,1,1},{1,1,0,0},{1,1,0,0}},eg[List[#]]&/@edges,
{{0,2,0},{2,0,0},{0,0,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}]]&@edges,
{{0,2,1},{2,0,0},{1,0,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}]]&@edges,
{{0,2,0},{2,0,1},{0,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}]]&@edges,
{{0,1,2},{1,0,0},{2,0,0}},List[eg[{#[[1]],#[[3]]}],eg[{#[[2]]}]]&@edges,
{{0,0,2},{0,0,1},{2,1,0}},List[eg[{#[[1]],#[[3]]}],eg[{#[[2]]}]]&@edges,
{{0,1,0},{1,0,2},{0,2,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}]]&@edges,
{{0,0,1},{0,0,2},{1,2,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}]]&@edges,
{{0,1,1,0},{1,0,1,0},{1,1,0,2},{0,0,2,0}},List[eg[{#[[1]]}],eg[{#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,
{{0,1,0,1},{1,0,1,0},{0,1,0,2},{1,0,2,0}},List[eg[{#[[1]]}],eg[{#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,
{{0,1,1,1},{1,0,0,0},{1,0,0,2},{1,0,2,0}},List[eg[{#[[2]]}],eg[{#[[1]],#[[3]],#[[4]]}]]&@edges,
{{0,2,1,0},{2,0,0,0},{1,0,0,2},{0,0,2,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,
{{0,0,1,0},{0,0,2,1},{1,2,0,1},{0,1,1,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]],#[[4]]}]]&@edges,
{{0,0,1,1},{0,0,2,0},{1,2,0,1},{1,0,1,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,0,1,2},{0,0,1,0},{1,1,0,1},{2,0,1,0}},List[eg[{#[[2]]}],eg[{#[[1]],#[[3]],#[[4]]}]]&@edges,
{{0,1,0,1},{1,0,2,0},{0,2,0,1},{1,0,1,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,1,0,2},{1,0,1,0},{0,1,0,1},{2,0,1,0}},List[eg[{#[[2]]}],eg[{#[[1]],#[[4]]}],eg[{#[[3]]}]]&@edges,
{{0,2,1,0},{2,0,0,1},{1,0,0,1},{0,1,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,2,0,1},{2,0,1,0},{0,1,0,1},{1,0,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,2,1,1},{2,0,0,0},{1,0,0,1},{1,0,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,1,1,0},{1,0,2,1},{1,2,0,0},{0,1,0,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,0,1,1},{0,0,2,1},{1,2,0,0},{1,1,0,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,0,1,2},{0,0,2,0},{1,2,0,0},{2,0,0,0}},List[eg[{#[[1]],#[[4]]}],eg[{#[[2]],#[[3]]}]]&@edges,
{{0,1,1,2},{1,0,1,0},{1,1,0,0},{2,0,0,0}},List[eg[{#[[2]]}],eg[{#[[1]],#[[4]]}],eg[{#[[3]]}]]&@edges,
{{0,2,0,1},{2,0,2,0},{0,2,0,0},{1,0,0,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,1,0,2},{1,0,2,0},{0,2,0,0},{2,0,0,0}},List[eg[{#[[1]],#[[4]]}],eg[{#[[2]],#[[3]]}]]&@edges,
{{0,2,1,1},{2,0,0,1},{1,0,0,0},{1,1,0,0}},List[eg[{#[[1]],#[[2]],#[[4]]}],eg[{#[[3]]}]]&@edges,
{{0,2,0,2},{2,0,1,0},{0,1,0,0},{2,0,0,0}},List[eg[{#[[1]],#[[2]],#[[4]]}],eg[{#[[3]]}]]&@edges,
{{0,1,0,1},{1,0,2,0},{0,2,0,1},{1,0,1,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,2,1,0},{2,0,1,0},{1,1,0,1},{0,0,1,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,2,0,1},{2,0,1,0},{0,1,0,1},{1,0,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,1,1,1},{1,0,2,0},{1,2,0,0},{1,0,0,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
 {{0,2,1,0},{2,0,1,1},{1,1,0,0},{0,1,0,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,1,0,0},{1,0,2,0},{0,2,0,2},{0,0,2,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]],#[[4]]}]]&@edges,
{{0,2,0,0},{2,0,1,0},{0,1,0,2},{0,0,2,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,
{{0,1,1,1},{1,0,2,0},{1,2,0,0},{1,0,0,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
{{0,2,0,0},{2,0,2,0},{0,2,0,1},{0,0,1,0}},List[eg[{#[[1]],#[[2]],#[[3]]}],eg[{#[[4]]}]]&@edges,
_,Print["Non-ext Error ",Jm]]];
genEdgeGroupExtremal[edges_,Jm_]:=If[(4Length[#]-2-Nest[Total,#,2])&@Jm<=0,{eg[edges]},
Switch[Jm,
{{0,2},{2,0}},eg[List[#]]&/@edges,
{{0,1,1},{1,0,1},{1,1,0}},eg[List[#]]&/@edges,
{{0,1,1},{1,0,2},{1,2,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]]}]]&@edges,
{{0,2,1},{2,0,1},{1,1,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]]}]]&@edges,
{{0,1,1,1},{1,0,1,1},{1,1,0,1},{1,1,1,0}},eg[List[#]]&/@edges,
{{0,2,0,1},{2,0,1,0},{0,1,0,2},{1,0,2,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,
{{0,0,1,1},{0,0,2,1},{1,2,0,1},{1,1,1,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]],#[[4]]}]]&@edges,
{{0,0,1,2},{0,0,1,1},{1,1,0,1},{2,1,1,0}},List[eg[{#[[1]],#[[3]],#[[4]]}],eg[{#[[2]]}]]&@edges,
{{0,1,0,1},{1,0,2,0},{0,2,0,2},{1,0,2,0}},List[eg[{#[[1]]}],eg[{#[[2]],#[[3]],#[[4]]}]]&@edges,{{0,1,1,0},{1,0,1,1},{1,1,0,2},{0,1,2,0}},List[eg[{#[[1]]}],eg[{#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,{{0,2,1,0},{2,0,0,1},{1,0,0,2},{0,1,2,0}},List[eg[{#[[1]],#[[2]]}],eg[{#[[3]],#[[4]]}]]&@edges,{{0,1,1,1},{1,0,0,1},{1,0,0,2},{1,1,2,0}},List[eg[{#[[1]],#[[3]],#[[4]]}],eg[{#[[2]]}]]&@edges,_,Print["Ext Error ",Jm]]];
